package com.example.file_path_copier

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
